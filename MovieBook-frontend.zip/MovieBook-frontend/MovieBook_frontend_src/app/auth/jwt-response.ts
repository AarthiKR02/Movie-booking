export class JwtResponse {

    token!: string;
    type!: string;
    username!: string;
    authorities!: string[];
  }