import {RecipeCategory} from './recipe-category';

export interface OptionCategory {
  id: RecipeCategory;
  name: string;
}