package cooking.book.repository;

import cooking.book.model.Movie;
import cooking.book.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

    int countByMovie(Movie movie);

    List<Ticket> findAllByUser_Username(String username);
}
