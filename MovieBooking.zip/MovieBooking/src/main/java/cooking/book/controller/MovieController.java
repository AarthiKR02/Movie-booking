package cooking.book.controller;

import cooking.book.dto.MovieRequest;
import cooking.book.exception.DetailsNotFoundException;
import cooking.book.exception.UsernameNotFoundException;
import cooking.book.message.request.TicketBookingRequest;
import cooking.book.model.Movie;
//import cooking.book.model.Theatre;
import cooking.book.model.Ticket;
import cooking.book.model.user.User;
import cooking.book.repository.MovieRepository;
//import cooking.book.repository.TheatreRepository;
import cooking.book.repository.TicketRepository;
import cooking.book.repository.user.UserRepository;
import cooking.book.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/api/movies")
@CrossOrigin(origins = "*")
public class MovieController {

    private MovieService movieService;
    private MovieRepository movieRepository;
    private TicketRepository ticketRepository;
    private UserRepository userRepository;
//    private TheatreRepository theatreRepository;

    @Autowired
    public MovieController(MovieService movieService, MovieRepository movieRepository, TicketRepository ticketRepository, UserRepository userRepository) {
        this.ticketRepository = ticketRepository;
        this.movieService = movieService;
        this.movieRepository = movieRepository;
        this.userRepository = userRepository;
    }

    @PreAuthorize(value = "hasAnyAuthority('USER', 'ADMIN')")
    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Movie> getAll(){
        return movieRepository.findAll();
    }

    @GetMapping("/{movieId}")
    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    public Movie getMovieById(@PathVariable Long movieId) {
        return movieRepository.findById(movieId)
                .orElseThrow(() -> new DetailsNotFoundException("Movie not found with id: " + movieId));
    }

    @PreAuthorize(value = "hasAnyAuthority('USER', 'ADMIN')")
    @GetMapping(value = "/all/byName/{term}")
    public List<Movie> getAllByName(@PathVariable String term){
    	List<Movie> movielist= movieRepository.findAllByNameContainingIgnoreCase(term);
    	if(movielist.isEmpty()) {
    		throw new DetailsNotFoundException("Movie with the term "+term+" Not Found");
    	}
    	return movielist;
    }

    @PreAuthorize(value = "hasAnyAuthority('USER', 'ADMIN')")
    @PostMapping("/book")
    public List<Ticket> bookTicket(Long movieId, int numberOfTickets, String seatNumber) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new DetailsNotFoundException("Movie not found with id: " + movieId));

        List<Ticket> tickets = new ArrayList<>();
        for (int i = 0; i < numberOfTickets; i++) {
            Ticket ticket = new Ticket();
            ticket.setMovie(movie);
            ticket.setUser(user); // Set the user here
            ticket.setSeatNumber(seatNumber);
            tickets.add(ticketRepository.save(ticket));
        }
        movieService.updateMovieStatus(movie);
        movieRepository.save(movie);
        return tickets;
    }
//    public List<Ticket> bookTickets(@Valid @RequestBody TicketBookingRequest request) {
//        List<Ticket> ticket = movieService.bookTicket(
//                request.getMovieId(),
//                request.getNumberOfTickets(),
//                request.getSeatNumber()
//        );
//        movieService.updateMovieStatus(ticket.get(0).getMovie());
//        return ticket;
//    }

    @GetMapping("/my_tickets")
    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    public List<Ticket> getMyTickets() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return ticketRepository.findAllByUser_Username(username);
    }

    @PostMapping("/add")
    @PreAuthorize("hasAuthority('ADMIN')")
    public Movie addMovie(@Valid @RequestBody MovieRequest movieRequest) {
        Movie movie = new Movie();
        movie.setName(movieRequest.getName());
        movie.setTotalTickets(movieRequest.getTotalTickets());
        movie.setStatus("Available");
        movie.setTheatreName(movieRequest.getTheatreName());
        return movieRepository.save(movie);
    }


    @PutMapping("/{movieId}/update-status")
    @PreAuthorize("hasAuthority('ADMIN')")
    public Movie updateMovieStatus(@PathVariable Long movieId) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new DetailsNotFoundException("Movie not found with id: " + movieId));
        movieService.updateMovieStatus(movie);
        return movieRepository.save(movie);
    }

    @DeleteMapping("/{movieId}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public void deleteMovie(@PathVariable Long movieId) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new DetailsNotFoundException("Movie not found with id: " + movieId));
        movieRepository.delete(movie);
    }



}


