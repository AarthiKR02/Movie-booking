package cooking.book.service;

import cooking.book.exception.DetailsNotFoundException;
import cooking.book.model.Movie;
//import cooking.book.model.Theatre;
import cooking.book.model.Ticket;
import cooking.book.repository.MovieRepository;
//import cooking.book.repository.TheatreRepository;
import cooking.book.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class MovieService {

    @Autowired
    private MovieRepository movieRepository;

//    @Autowired
//    private TheatreRepository theatreRepository;

    @Autowired
    private TicketRepository ticketRepository;


    public List<Ticket> bookTicket(Long movieId, int numberOfTickets, List<String> seatNumbers) {
        Movie movie = movieRepository.findById(movieId)
            .orElseThrow(NoSuchElementException::new);
        if (movie.getTotalTickets() <= 0 || movie.getTotalTickets() < numberOfTickets) {
            throw new DetailsNotFoundException("Not enough tickets available");
        }
        List<Ticket> tickets = new ArrayList<>();
        for (String seatNumber : seatNumbers) {
            Ticket ticket = new Ticket();
            ticket.setMovie(movie);
            ticket.setNumberOfTickets(1); // Each ticket is for one seat
            ticket.setSeatNumber(seatNumber);
            tickets.add(ticketRepository.save(ticket));
        }
        return tickets;
    }

    public void updateMovieStatus(Movie movie) {
        int booked = ticketRepository.countByMovie(movie);
        int ticketsLeft = movie.getTotalTickets() - booked;
        movie.setTotalTickets(ticketsLeft);
        if (ticketsLeft <= 0) {
            movie.setStatus("SOLD OUT");
        } else if (ticketsLeft <= 10) {
            movie.setStatus("BOOK ASAP");
        } else {
            movie.setStatus("Available");
        }
        movieRepository.save(movie);
    }
}
