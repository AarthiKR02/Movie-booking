package cooking.book.model.user;

public enum RoleName {
    ADMIN, USER
}
