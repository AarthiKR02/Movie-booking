package cooking.book.model;

import java.util.List;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
public class Movie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int totalTickets;
    private String status; // SOLD OUT or BOOK ASAP

    @OneToMany(mappedBy = "movie")
    @JsonIgnore
    private List<Ticket> tickets;

    private String theatreName;


}

